<?php

    global $wpdb;
    // Fields Starts Here
    $full_name = '';
    $permit_no = '';
    $permit_issue_date = '';
    $permit_expiry = '';
    $date_of_birth = '';
    $email = '';
    $student_address = '';
    $city = '';
    $state_name = '';
    $zip = '';
    $home_phone = '';
    $cell_phone = '';
    $age = '';
    $school_name = '';
    $gpa = '';
    $when2start = '';
    $sch_date = '';
    $sch_time = '';
    
    // $full_name = '';
    // $t_learnerPermit = '';
    // $t_issueDate = '';
    // $t_expirationDate = '';
    // $t_Dob = '';
    // $t_email = '';
    // $t_Address = '';
    // $t_CityName = '';
    // $t_State = '';
    // $t_zipCode = '';
    // $t_homePhone = '';
    // $t_cellPhone = '';
    // $t_wdys = '';
    // $s_age = '';
    // $t_gpa = '';
    // $t_highSchoolName = '';
    // $s_class = '';
    // $scheduledDate = '';
    // $scheduledTime = '';
    
    // Necessary Variables
    $notice = '';
    $wpsfTable = $wpdb->prefix.'wpsf_mails';
    
    function bringRecord($id){
        global $wpdb;
        $wpsfTable = $wpdb->prefix.'wpsf_mails';
        $selectedRow = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM ".$wpsfTable." WHERE id=%d",$id ), ARRAY_A // ARRAY_A convert object into array for $inserted_row with isset() function
        ); 
        return $selectedRow;
    }

    $page_title = 'Update Registrations';
    $form_type = 'update_eagle_reg';
    $submit_btn_name = 'submit_update_reg';

    $action = isset($_REQUEST['action']) ? trim($_REQUEST['action']) : "";
    $mail_id = isset($_REQUEST['mail_id']) ? trim($_REQUEST['mail_id']) : "";
    $form_action = $_SERVER['PHP_SELF'].'?page=wp_simple_regs&action=wpsf_edit_mail';

    require_once WPSF_PLUGIN_PATH .'inc/validate.php';
    require_once WPSF_PLUGIN_PATH .'inc/process.php';

    if($action == 'wpsf_add_mail'){
        $page_title = 'Add New Registrations';
        $form_type = 'add_eagle_reg';
        $submit_btn_name = 'submit_new_reg';
    }
    elseif(isset($_POST['submit_new_reg'])) {
        print_r($_POST);

        $proceed = 'true';
        // $ctitle = validate('alphanum', $_POST['wpsf_title']);
        // $cmailto = validate('email', $_POST['wpsf_mailTo']);
        // $cmailfrom = validate('alphanumbr', $_POST['wpsf_mailFrom']);
        // $csubject = validate('alphanum', $_POST['wpsf_subject']);
        // if($ctitle == 'false'){ $proceed = 'false'; }
        // if($cmailto == 'false'){ $proceed = 'false'; }
        // if($cmailfrom == 'false'){ $proceed = 'false'; }
        // if($csubject == 'false'){ $proceed = 'false'; }
        if($proceed) {
            $wpdb->insert($wpsfTable, array(
                "full_name" => $_POST[''],
                "permit_no" => $_POST[''],
                "permit_issue_date" => $_POST[''],
                "permit_expiry" => $_POST[''],
                "date_of_birth" => $_POST[''],
                "email" => $_POST[''],
                "student_address" => $_POST[''],
                "city" => $_POST[''],
                "state_name" => $_POST[''],
                "zip" => $_POST[''],
                "home_phone" => $_POST[''],
                "cell_phone" => $_POST[''],
                "age" => $_POST[''],
                "school_name" => $_POST[''],
                "gpa" => $_POST[''],
                "when2start" => $_POST[''],
                "sch_date" => $_POST[''],
                "sch_time" => $_POST['']
            ));
            $new_record = $wpdb->insert_id;
            $form_action .= '&mail_id='.$new_record;
            $inserted_row = bringRecord($new_record); // select * Query
            extract($inserted_row); // Get array and Assign variables with same name
            // Message Printing
            if( $new_record > 0 ) {
                $notice = '<div id="message" class="updated notice is-dismissible">';
                $notice .= '<p>Registration has been <strong>saved</strong> Successfully.</p>';
                $notice .= '<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>';
                $notice .= '</div>';
            }
            else {
                $notice = '<div id="message" class="error notice is-dismissible">';
                $notice .= '<p><strong>Failed</strong> to save Registration.</p>';
                $notice .= '<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>';
                $notice .= '</div>';
            }
        }
    }
    else {
        $edit_row = bringRecord($mail_id); // select * Query
        // extract($edit_row); // Get array and Assign variables with same name
        if(!empty($mail_id)){
            $form_action .= '&mail_id='.$mail_id;
            if(isset($_POST['submit_update_reg'])){
                $proceed = 'true';
                $utitle = validate('alphanum', $_POST['wpsf_title']);
                $umailto = validate('email', $_POST['wpsf_mailTo']);
                $umailfrom = validate('alphanumbr', $_POST['wpsf_mailFrom']);
                $usubject = validate('alphanum', $_POST['wpsf_subject']);
                if($utitle == 'false'){ $proceed = 'false'; }
                if($umailto == 'false'){ $proceed = 'false'; }
                if($umailfrom == 'false'){ $proceed = 'false'; }
                if($usubject == 'false'){ $proceed = 'false'; }
                $uform = process_data($_POST['wpsf_form']);
                $ublockWords = process_data($_POST['wpsf_blockKeywords']);
                if($proceed){
                    $wpdb->update($wpsfTable, array(
                        "full_name" => $_POST[''],
                        "permit_no" => $_POST[''],
                        "permit_issue_date" => $_POST[''],
                        "permit_expiry" => $_POST[''],
                        "date_of_birth" => $_POST[''],
                        "email" => $_POST[''],
                        "student_address" => $_POST[''],
                        "city" => $_POST[''],
                        "state_name" => $_POST[''],
                        "zip" => $_POST[''],
                        "home_phone" => $_POST[''],
                        "cell_phone" => $_POST[''],
                        "age" => $_POST[''],
                        "school_name" => $_POST[''],
                        "gpa" => $_POST[''],
                        "when2start" => $_POST[''],
                        "sch_date" => $_POST[''],
                        "sch_time" => $_POST['']
                    ), array('id'=>$mail_id));
                    $updatedRecord = bringRecord($mail_id); // select * Query
                    extract($updatedRecord); // Get array and Assign variables with same name
                    $form = base64_decode($form);
                    $block_keywords = base64_decode($block_keywords);
                    if( $mail_id > 0 ) {
                        $notice = '<div id="message" class="updated notice is-dismissible">';
                        $notice .= '<p>Form has been <strong>updated</strong> Successfully.</p>';
                        $notice .= '<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>';
                        $notice .= '</div>';
                    }
                }
            }
        }
        else {
            $notice = '<div id="message" class="error notice is-dismissible">';
            $notice .= '<p>No Registrations selected! Please select <a href="'.$_SERVER['PHP_SELF'].'?page=wp_simple_regs">Registrations from List</a> and then choose <strong>edit</strong> to make changes </p>';
            $notice .= '<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>';
            $notice .= '</div>';
        }

    }

?>
<div class="wrap">

    <h1 class="wp-heading-inline"><?php echo $page_title; ?></h1>
    <hr class="wp-header-end">

    <?php echo $notice; ?>

    <div class="page-content wpsf wpsf_form">

        <form method="post" name="<?php echo $form_type; ?>" action="<?php echo $form_action; ?>">

            <div class="row form-group">
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_fullName">Full Name <span>*</span></label>
                    <input type="text" name="full_name" value="<?php echo $full_name; ?>" class="validates-as-required form-control" id="t_fullName" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_learnerPermit">Learners Permit# <span>*</span></label>
                    <input type="text" name="t_learnerPermit" value="<?php echo $permit_no; ?>" class="validates-as-required form-control" id="t_learnerPermit" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_issueDate">Issue Date <span>*</span></label>
                    <input type="text" name="t_issueDate" value="<?php echo $permit_issue_date; ?>" class="validates-as-required form-control" id="t_issueDate" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_expirationDate">Expiration Date <span>*</span></label>
                    <input type="text" name="t_expirationDate" value="<?php echo $permit_expiry; ?>" class="validates-as-required form-control" id="t_expirationDate" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_Dob">Date of Birth <span>*</span></label>
                    <input type="text" name="t_Dob" value="<?php echo $date_of_birth; ?>" class="validates-as-required form-control" id="t_Dob" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_email">Email ID <span>*</span></label>
                    <input type="email" name="t_email" value="<?php echo $email; ?>" class="wpcf7-required email validates-as-required wpcf7-validates-as-email form-control" id="t_email" />
                </div>
                <div class="col-xs-12 mb-20">
                    <label class="text-black" for="t_Address">Address <span>*</span></label>
                    <input type="text" name="t_Address" value="<?php echo $student_address; ?>" class="validates-as-required form-control" id="t_Address" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_CityName">City Name <span>*</span></label>
                    <input type="text" name="t_CityName" value="<?php echo $city; ?>" class="validates-as-required form-control" id="t_CityName" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_State">State <span>*</span></label>
                    <input type="text" name="t_State" value="<?php echo $state_name; ?>" class="validates-as-required form-control" id="t_State" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_zipCode">Zip Code <span>*</span></label>
                    <input type="text" name="t_zipCode" value="<?php echo $zip; ?>" class="validates-as-required form-control" id="t_zipCode" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_homePhone">Home Phone</label>
                    <input type="text" name="t_homePhone" value="<?php echo $home_phone; ?>" class="form-control" id="t_homePhone" aria-invalid="false" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_cellPhone">Cell Phone <span>*</span></label>
                    <input type="text" name="t_cellPhone" value="<?php echo $cell_phone; ?>" class="validates-as-required form-control" id="t_cellPhone" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_wdys">When Do you want to Start</label>
                    <input type="text" name="t_wdys" value="<?php echo $when2start; ?>" class="form-control" id="t_wdys" aria-invalid="false" />
                </div>
            </div>
            <div class="row isAdult">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="eRadio mt-10 mb-20">
                        <input type="radio" checked name="s_age" id="below18" value="<?php echo $age; ?>" />
                        <label for="below18">I'm below 18 years old</label>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="eRadio mt-10 mb-20">
                        <input type="radio" name="s_age" id="above18" value="<?php echo $age; ?>" />
                        <label for="above18">I'm above 18 years old</label>
                    </div>
                </div>
            </div>
            <div class="row teenFields">
                <div class="col-xs-12 col-sm-6 col-md-4 mb-20">
                    <label class="text-black" for="t_gpa">Your GPA <span>*</span></label>
                    <input type="text" name="t_gpa" value="<?php echo $gpa; ?>" class="validates-as-required form-control" id="t_gpa" />
                </div>
                <div class="col-xs-12 col-sm-6 col-md-8 mb-20">
                    <label class="text-black" for="t_highSchoolName">High School Name</label>
                    <input type="text" name="t_highSchoolName" value="<?php echo $school_name; ?>" class="form-control" id="t_highSchoolName" aria-invalid="false" />
                </div>
            </div>
            <div class="row scheduleClass">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="eRadio mt-10 mb-20">
                        <input type="radio" checked name="s_class" id="scheduleNow" />
                        <label for="scheduleNow">Schedule my class now</label>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="eRadio mt-10 mb-20">
                        <input type="radio" name="s_class" id="scheduleLater" />
                        <label for="scheduleLater">Schedule my class later</label>
                    </div>
                </div>
            </div>
            <div class="row scheduleFields form-group ">
                <div class="col-xs-12 col-sm-6 mb-20">
                    <label class="text-black" for="schDate">Date <span>*</span></label>
                    <input name="scheduledDate" type="text" value="<?php echo $sch_date; ?>" data-field="date" data-format="dd-MMM-yyyy" readonly class="form-control" id="schDate" />
                </div>
                <div class="col-xs-12 col-sm-6 mb-20">
                    <label class="text-black" for="schTime">Time <span>*</span></label>
                    <input name="scheduledTime" type="text" value="<?php echo $sch_time; ?>" data-field="time" data-format="hh:mm AA" readonly class="form-control" id="schTime" />
                </div>
            </div>
            <div class="row form-group">
                <div class="col-xs-12 mb-20">
                    <button class="wpsf_btn wpsf_primary" type="submit" name="<?php echo $submit_btn_name; ?>">Register</button>
                </div>
            </div>

        </form>

    </div>
</div>
